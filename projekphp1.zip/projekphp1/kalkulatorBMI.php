<?php
include_once 'header.php';
include_once 'sidebar.php';
require_once 'projek1.php';
?>
<div class="content-wrapper">

<?php
error_reporting (E_ALL ^ E_WARNING || E_NOTICE);
$psn1 = new Pasien("Maryam Siti","P");
$psn2 = new Pasien("Hamzah Syah","L");
$psn3 = new Pasien("Arham Riyandi","L");

$bmi1 = new BMI(60,165);
$bmi2 = new BMI(53,171);
$bmi3 = new BMI(68,175);

$bpsn1 = new BMIPasien($bmi1,$psn1);
$bpsn1->tanggal = "2022-02-10";
$bpsn2 = new BMIPasien($bmi2,$psn2);
$bpsn2->tanggal = "2022-03-12";
$bpsn3 = new BMIPasien($bmi3,$psn3);
$bpsn3->tanggal = "2022-04-07";

$ar_pasien = [$bpsn1,$bpsn2,$bpsn3];

$_tanggal = $_POST['Tanggal'];
$_nama = $_POST['nama'];
$_gender = $_POST['gender'];
$_berat = $_POST['berat'];
$_tinggi = $_POST['tinggi'];

$psn4 = new Pasien($_nama,$_gender);
$bmi4 = new BMI($_berat,$_tinggi);
$bpsn4 = new BMIPasien($bmi4,$psn4);
$bpsn4 -> tanggal = $_tanggal;

array_push($ar_pasien,$bpsn4);
?>
<br><hr>
<div class="container">
<table class="table table-striped" bor>
    <thead class="thead-dark">
        <tr>
            <th>No</th><th>Tanggal Periksa</th><th>kode pasien</th>
            <th>Nama Pasien</th><th>Gender</th><th>Berat (kg)</th><th>Tinggi (cm)</th>
            <th>Nilai BMI</th><th>Status BMI</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $nomor=1;
            $kode='R013';
            foreach($ar_pasien as $obj){
        ?>
            <tr>
                <td><?=$nomor?></td>
                <td><?=$obj->tanggal?></td>
                <td><?=$kode?></td>
                <td><?=$obj->pasien->nama?></td>
                <td><?=$obj->pasien->gender?></td>
                <td><?=$obj->bmi->berat?></td>
                <td><?=$obj->bmi->tinggi?></td>
                <td><?=$obj->bmi->nilaiBMI()?></td>
                <td><?=$obj->bmi->statusBMI()?></td>
            </tr>
        <?php
            $nomor++;
            $kode++;
            }
        ?>
    </tbody>
</table>
</div>
        </div>
<?php
include_once 'footer.php'
?>